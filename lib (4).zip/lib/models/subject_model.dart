class SubjectModel {
  final String id;
  final String name;
  final String code; // e.g. BT101
  final String branch; // BIO-TECH-UG / BIO-TECH-PG
  final String semester; // SEM-I ... SEM-VI
  final String year; // FY / SY / TY
  final String addedBy; // professor UID
  final String addedByName;
  final DateTime createdAt;
  final double regularFee; // exam fee for regular students
  final double backlogFee; // exam fee for backlog/ATKT students

  SubjectModel({
    required this.id,
    required this.name,
    this.code = '',
    required this.branch,
    required this.semester,
    required this.year,
    required this.addedBy,
    this.addedByName = '',
    required this.createdAt,
    this.regularFee = 0,
    this.backlogFee = 0,
  });

  factory SubjectModel.fromMap(Map<String, dynamic> map, String id) {
    return SubjectModel(
      id: id,
      name: map['name'] ?? '',
      code: map['code'] ?? '',
      branch: map['branch'] ?? '',
      semester: map['semester'] ?? '',
      year: map['year'] ?? '',
      addedBy: map['addedBy'] ?? '',
      addedByName: map['addedByName'] ?? '',
      createdAt: (map['createdAt'] as dynamic)?.toDate() ?? DateTime.now(),
      regularFee: (map['regularFee'] ?? 0).toDouble(),
      backlogFee: (map['backlogFee'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'code': code,
    'branch': branch,
    'semester': semester,
    'year': year,
    'addedBy': addedBy,
    'addedByName': addedByName,
    'createdAt': createdAt,
    'regularFee': regularFee,
    'backlogFee': backlogFee,
  };

  SubjectModel copyWith({double? regularFee, double? backlogFee}) => SubjectModel(
    id: id, name: name, code: code, branch: branch, semester: semester,
    year: year, addedBy: addedBy, addedByName: addedByName, createdAt: createdAt,
    regularFee: regularFee ?? this.regularFee,
    backlogFee: backlogFee ?? this.backlogFee,
  );

  String get displayName => code.isNotEmpty ? '$code — $name' : name;
}
